import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:jwt_decoder/jwt_decoder.dart';
import 'package:sample/models/api_models/api_models.dart';
import 'package:sample/models/localstorage_models/local_reference.dart';
import 'package:sample/models/localstorage_models/local_storage_functions.dart';
import 'package:sample/screen/second%20page.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  // email = email-id is not registered
  // pass = password wrong
  var token = "";
  getToken() async {
    token = await LocalStorageFunctions.instance
        .readData(LocalStorageReference.apiToken);
    print("local token is  : $token");
  }

  apiFetchFun() async {
    String email = "ram@gmail.com";
    String password = "12345";
    try {
      Uri url = Uri.parse(ApiDatas.instance.signinApi);
      final response = await http.post(url,
          headers: <String, String>{
            'Content-Type': 'application/json; charset=UTF-8',
          },
          body: json.encode({"email": email, "pass": password}));
      if (response.statusCode == 200) {
        var data = json.decode(response.body);
        if (data['result'] != "email-id is not registered" &&
            data['result'] != "password wrong") {
          print("success");
          var token = data['token'];
          LocalStorageFunctions obj = LocalStorageFunctions.instance;
          var res = await obj.writeData(LocalStorageReference.apiToken, token);
          print(res);
          getToken();
        } else {
          print("email or password is wrong...");
        }
      } else {
        print("failed");
        print(response.statusCode);
      }
    } catch (e) {
      print("error is : $e");
    }
  }

  tokenValidityCheck() async {
    if (JwtDecoder.isExpired(token)) {
      print("Token is Expired");
      apiFetchFun();
    } else {
      print("not Expired");
      print(JwtDecoder.getRemainingTime(token).inSeconds);
    }
  }

  @override
  void initState() {
    apiFetchFun();
    Timer.periodic(const Duration(seconds: 5), (timer) {
      tokenValidityCheck();
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Home Page"),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
                onPressed: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const SecondPage()));
                },
                child: const Text("Next Screen")),
          ],
        ),
      ),
    );
  }
}
