import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class LocalStorageFunctions {
  final storage = const FlutterSecureStorage();
  static LocalStorageFunctions instance = LocalStorageFunctions();

  writeData(key, value) async {
    await storage.write(key: key, value: value);
    return "successfully Inserted";
  }

  readData(key) async {
    var data = await storage.read(key: key);
    return data;
  }
}
