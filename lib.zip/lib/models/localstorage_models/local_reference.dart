class LocalStorageReference {
  static String apiToken = "hidden_token";
}
