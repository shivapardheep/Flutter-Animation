class ApiDatas {
  static ApiDatas instance = ApiDatas();

  String signinApi =
      "https://flask-restapi-token-auth.herokuapp.com/auth/signin";
}
